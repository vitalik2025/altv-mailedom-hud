﻿var HUD = new Vue({
    el: ".hud_wrapper",
    data: {
        show: true,
		bonusblock: false,
		lastbonus: "2:26",
        ammo: 0,
        money: "117 000 000",
        bank: "17 121 212",
        mic: false,
        time: "02:01",
        date: "22.04.2021",
        dateF: "суббота",
        street: "Гора Чиллиад",
        crossingRoad: "Шоссе Сенора",
        server: 1,
        playerId : 0,
		personId: 0,
        online: 0,
        inVeh: true,
		belt: false,
        engine: false,
        doors: false,

        activebonus: true,
        helpshow: true,


        eat: 100,
        water: 50,
        ilight: -1,
        light: 1,
        gear: 2,
        speed: 10,
        hp: 0,
        maxhp: 1000,
        fuel: 100,
        maxfuel: 100,
        brake: false,

        intervalT: null,

        help: 
        [
            {key: "G", desc: "Взимодействие"},
            {key: "I", desc: "Инвентарь"},
            {key: "N", desc: "Голосовой чат"},
            {key: "L", desc: "Замок Т/С"},
            {key: "F4", desc: "Скрыть подсказки"},
            {key: "F5", desc: "Скрыть худ"},
            {key: "[", desc: "Скрыть бонус"},
            {key: "Ё", desc: "Курсор"},
        ],
    },
    methods: {
        setTime: (time, date) => {
            this.time = time;
            this.date = date;
        }, 
		showBonus(){
			this.bonusblock = !this.bonusblock;
		},
        getSpeed(){
            let num = 659.734 + (this.speed * 100 / 300) * 4.74;
            return num > 1130.734 ? 1130.734 : num;
        },
        Test( ) {
            this.speed = 0;
            let interval = setInterval(()=> {
                if (this.speed < 300)
                    this.speed += 1;
                else
                    clearInterval(interval);
            }, 25)
        },
        newTime() {
            let date = new Date();
            var options = {
                weekday: 'long',
            };
            this.dateF = date.toLocaleString("ru", options);
        }
    }
})


setInterval( () => {
    HUD.newTime();
}, 2500);

var lastW = 0;
var lastR = 0;

function updatehud(width, ratio,safezone,offset=0) {

    lastW = width; lastR = ratio;

   let y1 = 316, y2 = 436;

    if(width > 2100) {
        offset += 98;
        
        document.querySelector(".mappings").style['bottom'] = '1px';
    }

    if(width < 1440) {
        offset -= 92;
        y2 = 404;

        document.querySelector(".mappings").style.bottom = '13px';
        document.querySelector(".mappings").style.transform = 'scale(0.75)';
    }

    if(width < 1320) {
        offset -= 67;
        document.querySelector(".mappings").style.bottom = '13px';
        document.querySelector(".mappings").style.transform = 'scale(0.75)';
    }

    const m = (y2 - y1) / (5/4 - 16/9);
    const b = y1 - (m * 16 / 9);

    document.querySelector(".mappings").style.left = `${m * ratio + b + offset}px`;
    
}

$(document).ready(() => {
    window.mapAPI = {
        on: () => {
            updatehud(lastW,lastR,false,lastW * 0.091);
        },
        off: () => {
            updatehud(lastW,lastR,false,0);
        },
    };
});
